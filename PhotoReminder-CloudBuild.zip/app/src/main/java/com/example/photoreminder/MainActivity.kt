package com.example.photoreminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("photos", Context.MODE_PRIVATE) }
    private val photos get() = prefs.getStringSet("uris", emptySet())?.toList() ?: emptyList()
    private lateinit var status: TextView

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        val saved = photos.toMutableSet()
        uris.forEach {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            saved.add(it.toString())
        }
        prefs.edit().putStringSet("uris", saved).apply()
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(0xFFF7F5FA.toInt())
        }
        val title = TextView(this).apply { text = "Photo Reminder"; textSize = 26f; setTextColor(0xFF241D2B.toInt()) }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 24, 0, 24) }
        val add = Button(this).apply { text = "افزودن عکس از گالری"; setOnClickListener { picker.launch(arrayOf("image/*")) } }
        val start = Button(this).apply { text = "شروع اعلان هر ۳ دقیقه"; setOnClickListener { startReminders() } }
        val stop = Button(this).apply { text = "توقف اعلان‌ها"; setOnClickListener { ReminderScheduler.cancel(this@MainActivity); status.text = "اعلان‌ها متوقف شدند." } }
        val hint = TextView(this).apply { text = "عکس‌ها از مجموعه انتخابی شما نمایش داده می‌شوند."; textSize = 14f; setPadding(0, 24, 0, 0) }
        layout.addView(title); layout.addView(status); layout.addView(add); layout.addView(start); layout.addView(stop); layout.addView(hint)
        setContentView(layout); refresh(); requestNotificationPermission()
    }
    private fun refresh() { status.text = "تعداد عکس‌های ذخیره‌شده: ${photos.size}" }
    private fun startReminders() {
        if (photos.isEmpty()) { Toast.makeText(this, "اول حداقل یک عکس انتخاب کن.", Toast.LENGTH_LONG).show(); return }
        if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            Toast.makeText(this, "اجازه زمان‌بندی دقیق را فعال کن و دوباره شروع را بزن.", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putBoolean("running", true).apply()
        ReminderScheduler.schedule(this)
        status.text = "یادآوری فعال است؛ فاصله هدف ۳ دقیقه."
    }
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
    }
}
