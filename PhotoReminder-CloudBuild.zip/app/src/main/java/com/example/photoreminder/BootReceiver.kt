package com.example.photoreminder
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val p = context.getSharedPreferences("photos", Context.MODE_PRIVATE)
            if (p.getBoolean("running", false) && p.getStringSet("uris", emptySet())?.isNotEmpty() == true)
                ReminderScheduler.schedule(context)
        }
    }
}
