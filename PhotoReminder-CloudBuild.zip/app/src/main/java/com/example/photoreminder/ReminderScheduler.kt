package com.example.photoreminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderScheduler {
    private const val REQUEST = 7331
    fun schedule(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context)
        am.cancel(pi)
        val next = System.currentTimeMillis() + 3 * 60 * 1000L
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
        else am.setExact(AlarmManager.RTC_WAKEUP, next, pi)
    }
    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(context))
        context.getSharedPreferences("photos", Context.MODE_PRIVATE).edit().putBoolean("running", false).apply()
    }
    private fun pending(context: Context): PendingIntent =
        PendingIntent.getBroadcast(context, REQUEST, Intent(context, PhotoAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
}
